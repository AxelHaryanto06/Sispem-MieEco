<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
    <title>Register - Mie Eco</title>
</head>
<body>
    <div class="css-1">
        <div class="box-left register-image-left css-2">
            <div class="col-md-12 image-geser">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="/img/mieeco2 2.svg" width="219" height="auto" class="d-inline-block align-top" alt="">
                </a>
            </div>
            <figure class="gambar-register">
                <img src="/img/registerimage.png" alt="">
            </figure>
        </div>
        <div class="box-right register-image-right">
            <a href="<?php echo e(url('/')); ?>">
                <img src="/img/mie-eco-black.png" class="logo-mieeco" alt="Logo Mie Eco Black Outline">            
            </a>
            <div class="col-md-12 tulisan-register">Register</div>
            <div class="col-md-12 form-register">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="name" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Nama')); ?></label>

                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" placeholder="Masukkan Nama Anda" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>                                

                    <div class="form-group row">
                        <label for="jenkel" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Jenis Kelamin')); ?></label>

                        <div class="col-md-6 pilih-jenkel">
                            <div class="form-check pilihan">
                                <input class="form-check-input" type="radio" name="jenkel" id="jenkel" value="Laki - Laki" required>
                                <label class="form-check-label" for="jenkel">
                                    Laki - Laki
                                </label>
                            </div>
                            <div class="form-check pilihan">
                                <input class="form-check-input" type="radio" name="jenkel" id="jenkel" value="Perempuan" required>
                                <label class="form-check-label" for="jenkel">
                                    Perempuan
                                </label>
                            </div>

                            <?php if ($errors->has('jenkel')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenkel'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tgl_lahir" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Tanggal Lahir')); ?></label>

                        <div class="col-md-6">
                            <input id="tgl_lahir" type="date" class="form-control <?php if ($errors->has('tgl_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tgl_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="tgl_lahir" value="<?php echo e(old('tgl_lahir')); ?>" required autocomplete="tgl_lahir">

                            <?php if ($errors->has('tgl_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tgl_lahir'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="email" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Email')); ?></label>

                        <div class="col-md-6">
                            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" placeholder="Email Lengkap Anda" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="telepon" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Telepon')); ?></label>

                        <div class="col-md-6">
                            <input id="telepon" type="text" class="form-control <?php if ($errors->has('telepon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telepon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telepon" placeholder="Masukkan Nomor Anda" value="<?php echo e(old('telepon')); ?>" required autocomplete="telepon">

                            <?php if ($errors->has('telepon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telepon'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Password')); ?></label>

                        <div class="col-md-6">
                            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Masukkan Password Anda" required autocomplete="new-password">

                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-3 col-form-label text-md-left perintah"><?php echo e(__('Confirm Password')); ?></label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Konfirmasi Password Anda" required autocomplete="new-password">
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Register')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
                
    </div>
</body>
</html><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/auth/register.blade.php ENDPATH**/ ?>