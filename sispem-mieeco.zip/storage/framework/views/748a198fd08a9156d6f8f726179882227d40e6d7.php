<?php $__env->startSection('title', 'Detail Pemesanan | Mie Eco'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>                        
                        <li class="breadcrumb-item"><a href="<?php echo e(url('history')); ?>">Riwayat Pemesanan</a></li>                        
                        <li class="breadcrumb-item active" aria-current="page">Detail Pemesanan</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-12 mt-2">
                <div class="container">
                    <h5><i class="fas fa-shopping-cart"></i> Detail Pemesanan</h5>                
                    <?php if(!empty($pesanan)): ?>
                    <a href="<?php echo e(url('/history/bukti_pesan')); ?>/<?php echo e($pesanan->id); ?>" class="btn btn-primary btn-cetak mt-3" target="_blank">Cetak Bukti Pesan</a>
                    <div align="right" class="table-responsive mt-4">
                        <table class="table table-sm table-borderless w-auto">
                            <tbody>
                                <tr>
                                    <td>Layanan</td>
                                    <td>:</td>
                                    <td><?php echo e($pesanan->layanan->jenis); ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal Pesan</td>
                                    <td>:</td>
                                    <td><?php echo e($pesanan->tanggal); ?></td>
                                </tr>
                                <tr>
                                    <td>Jam</td>
                                    <td>:</td>
                                    <td><?php echo e($pesanan->jam); ?></td>
                                </tr>
                                <tr>
                                    <td>Kode Pesanan</td>
                                    <td>:</td>
                                    <td>ME201400<?php echo e($pesanan->id); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr class="table-active">                            
                                    <th class="cart-page-menu">Menu</th>
                                    <th class="th-menu">Kuantitas</th>
                                    <th class="th-menu">Harga</th>
                                    <th class="th-menu">Jumlah Harga</th>                            
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detail_pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                           
                                    <td>
                                        <div class="col-md-12 cart-page-namamenu">
                                            <?php echo e($detail_pesanan->menu->nama_menu); ?>

                                        </div>                                
                                        <div class="col-md-12 cart-page-catatan mt-2">
                                            <i><?php echo e($detail_pesanan->catatan); ?></i>
                                        </div>                                
                                    </td>
                                    <td style="text-align: center"><?php echo e($detail_pesanan->jumlah); ?></td>
                                    <td align="left">Rp. <?php echo e(number_format($detail_pesanan->menu->harga)); ?></td>
                                    <td align="left">Rp. <?php echo e(number_format($detail_pesanan->jml_harga)); ?></td>                            
                                </tr>                            
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="3" align="right"><strong>Total Harga :</strong></td>
                                    <td><strong>Rp. <?php echo e(number_format($pesanan->total)); ?></strong></td>                            
                                </tr>
                                <tr>
                                    
                                </tr>
                            </tbody>
                        </table>                    
                    </div>                
                    <?php endif; ?>
                    <div class="card mt-5">
                        <div class="card-header">
                            <h5><i class="fas fa-upload"></i> Upload Bukti Pembayaran</h5>
                        </div>
                        <div class="card-body">
                            <p>Silakan upload bukti pembayaran dibawah ini. Verifikasi akan dilakukan dalam beberapa waktu.</p>
                            <form action="<?php echo e(url('history/pembayaran')); ?>/<?php echo e($pesanan->id); ?>" enctype="multipart/form-data" method="post" accept-charset="utf-8">
                            <?php echo csrf_field(); ?>                            
                            <div class="form-group row">
                                <div class="col-sm-2">Contoh Bukti Pembayaran</div>
                                <div class="col-sm-10">                                  
                                <div class="row">
                                    <div class="col-sm-5 responsive">
                                        <img style="height: 200px; width: 270px; padding: 10px" src="/img/contoh1.jpeg" class="img-contoh" alt="Contoh Bukti Pembayaran">
                                    </div>
                                    <div class="col-sm-5">
                                        <div class="form-group">                                            
                                            <input type="file" class="form-control-file" id="foto_bukti" name="foto_bukti">
                                        </div>
                                        
                                        
                                    </div>
                                </div>        
                                <div class="col-sm-5 mt-3 text-center">
                                    <button type="submit" class="btn btn-secondary ">Upload</button>
                                </div>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                    <div class="card my-4">
                        <div class="card-header">
                            <h5><i class="fas fa-receipt"></i> Bukti Pembayaran</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($pembayaran->bukti_foto)): ?>
                                <img src="<?php echo e(url('img')); ?>/<?php echo e($pembayaran->bukti_foto); ?>" class="img-bukti-foto" alt="bukti_foto" width="400" height="200">
                            <?php else: ?>
                                <h5 class="card-title">Mohon Selesaikan Pembayaran Anda</h5>
                                <p>Bukti Pembayaran Tidak Ditemukan !</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/history/detail.blade.php ENDPATH**/ ?>