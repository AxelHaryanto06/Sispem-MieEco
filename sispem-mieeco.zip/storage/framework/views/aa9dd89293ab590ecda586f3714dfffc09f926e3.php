<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <h4>Laporan Penjualan</h4>
            <div class="box box-warning">
                <div class="box-header">                    
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>
                    <div class="form-inline date_range">
                        <div class="input-group">
                            <input type="date" name="tglawal" id="tglawal" class="form-control" required>
                        </div>                
                        <div class="input-group">
                            <input type="date" name="tglakhir" id="tglakhir" class="form-control" required>
                        </div>
                                                
                        <a href="" onclick="return PilihTanggal()" target="_blank" class="btn btn-primary" id="cetak"><i class="fa fa-print" aria-hidden="true"></i> Cetak Laporan</a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                            <table class="table myTable">
                                <thead class="text-primary">
                                    <th>No</th>
                                    <th>ID Pesanan</th>
                                    <th>Atas Nama</th>
                                    <th>Tanggal Pesan</th>                
                                    <th>Layanan</th>                                                            
                                    <th>Total</th>
                                </thead>
                                <tbody>
                                    <!-- <?php echo e($no = 1); ?> -->
                                    <?php $__currentLoopData = $data_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td>ME201400<?php echo e($jual->id); ?></td>
                                        <td><?php echo e($jual->user->name); ?></td>
                                        <td><?php echo e($jual->tanggal); ?></td>                
                                        <td><?php echo e($jual->layanan->jenis); ?></td>                                   
                                        <td class="text-right">Rp. <?php echo e(number_format($jual->total)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/page_laporanpenjualan.blade.php ENDPATH**/ ?>