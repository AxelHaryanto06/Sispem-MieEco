<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <h4>Daftar Menu</h4>
            <div class="box box-warning">
                <div class="box-header">
                    <p>
                        <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>
                        <a href="/admin/daftarmenu/tambah" class="btn btn-sm btn-flat btn-primary"><i class="fa fa-plus"></i> Tambah Menu</a>
                    </p>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                            <table class="table myTable">
                                <thead class="text-primary">
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Gambar Menu</th>
                                    <th>Deskripsi</th>
                                    <th>Harga</th>                            
                                    <th>Aksi</th>                                                            
                                </thead>
                                <tbody>
                                    <!-- <?php echo e($no = 1); ?> -->
                                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <tr>
                                        <td> <?php echo e($no++); ?> </td>
                                        <td> <?php echo e($m->nama_menu); ?> </td>
                                        <td> <img src="<?php echo e(url('img')); ?>/<?php echo e($m->gambar); ?>" widht="100px" height="100px" height alt="image"> </td>
                                        <td> <?php echo e($m->deskripsi); ?></td>
                                        <td> Rp. <?php echo e(number_format($m->harga)); ?> </td>
                                        <td>
                                            <a href="/admin/daftarmenu/edit/<?php echo e($m->id); ?>" class="btn btn-success">Edit</a>
                                            <a href="/admin/daftarmenu/hapus/<?php echo e($m->id); ?>" class="btn btn-danger">Delete</a>
                                        </td>                                    
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $(document).ready(function(){

        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/menu.blade.php ENDPATH**/ ?>