<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <img src="<?php echo e(public_path("/img/mieeco2 2.png")); ?>" width="219" height="41" class="d-inline-block align-top" alt="">    
    <table class="table table-bordered">
        <thead>
            <tr class="text-center">                            
                <th>No</th>
                <th>ID Pesanan</th>
                <th>Atas Nama</th>
                <th>Tanggal Pesan</th>                
                <th>Total</th>
                <th>Layanan</th>                                                     
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1
            ?>  
            <?php $__currentLoopData = $data_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>                           
                <td><?php echo e($no++); ?></td>
                <td>ME201400<?php echo e($pesan->id); ?></td>
                <td><?php echo e($pesan->user->name); ?></td>
                <td><?php echo e($pesan->tanggal); ?></td>                
                <td class="text-right">Rp. <?php echo e(number_format($pesan->total)); ?></td>
                <td><?php echo e($pesan->layanan->jenis); ?></td>                            
            </tr>                            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/laporanpesanan.blade.php ENDPATH**/ ?>