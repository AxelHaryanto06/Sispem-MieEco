<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
    <div class="col-md-12">
        <h4 class="pesan-judul">Detail Pemesanan</h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>                    
                </p>                
            </div>        
            <div class="col-md-12">                                
            </div>
            <div class="box-body">                
                    <?php if(!empty($detail_pesanans)): ?>                                    
                    <div class="table-responsive">
                            <table class="table table-bordered text-dark">
                                <thead class="text-primary">
                                    <th>No</th>                                    
                                    <th>Menu</th>
                                    <th>Jumlah</th>                                                                                                                                                                                      
                                    <th>Catatan</th>                                                                                                                                                                                      
                                </thead>
                                <tbody>
                                <?php
                                    $no = 1
                                ?>                                
                                <?php $__currentLoopData = $detail_pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                                                                                                                                                                                                                                          
                                        <td><?php echo e($no++); ?></td>                                                                                    
                                        <td><?php echo e($dp->menu->nama_menu); ?></td>
                                        <td><?php echo e($dp->jumlah); ?></td>                                                                                                                                                        
                                        <td>
                                            <?php if(!empty($dp->catatan)): ?>
                                                <?php echo e($dp->catatan); ?>

                                            <?php else: ?>
                                                Tidak ada catatan
                                            <?php endif; ?>                                            
                                        </td>                                                                                                                                                     
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>                                
                            </table>
                            <div>
                                <h4>Bukti Pembayaran</h4>
                                <?php if(!empty($pembayaran[0]->bukti_foto)): ?>
                                    <img src="<?php echo e(url('img')); ?>/<?php echo e($pembayaran[0]->bukti_foto); ?>" widht="300px" height="300px" height alt="image">                                
                                <?php else: ?>
                                    Belum Melakukan Pembayaran
                                <?php endif; ?>                                
                            </div>
                        </div>

                </div>
                
            <?php else: ?>
                <div class="box-body">
                    Data tidak ditemukan
                </div>
            <?php endif; ?>        
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/detailpesan.blade.php ENDPATH**/ ?>