<?php $__env->startSection('title', 'Riwayat Pesanan | Mie Eco'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>                        
                        <li class="breadcrumb-item active" aria-current="page">Riwayat Pemesanan</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-12 mt-2">
                <div class="container main">
                    <h5><i class="fas fa-history"></i> Riwayat Pemesanan</h5>
                    <div class="alert alert-warning order-announcement mt-2" role="alert">
                        *Pemesanan dengan status Belum Dibayar tidak akan diproses <br>
                        *Silakan unggah bukti pembayaran pesanan Anda dengan klik Detail

                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped mt-2">
                            <thead>
                                <tr>                            
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>                            
                            <?php
                                $no = 1
                            ?>
                            <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($pesanan->tanggal); ?></td>
                                    <td>
                                        <?php if($pesanan->pembayaran[0]->status_bayar == "1"): ?>
                                            Sudah Dibayar
                                        <?php else: ?>
                                            Belum Dibayar
                                        <?php endif; ?>
                                    </td>
                                    <td>Rp. <?php echo e(number_format($pesanan->total)); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('history')); ?>/<?php echo e($pesanan->id); ?>" class="btn btn-primary">Detail</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/history/index.blade.php ENDPATH**/ ?>