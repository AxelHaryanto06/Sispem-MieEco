<?php $__env->startSection('content'); ?>
<section class="content">
        <div class="row">
        <div class="col-md-12">
            <h4 class="pesan-judul">Pemesanan</h4>
            <div class="box box-warning">
                <div class="box-header">
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>                        
                    <div class="form-inline date_range">
                        <div class="input-group">
                            <input type="date" name="tglawal" id="tglawal" class="form-control" required>
                        </div>                
                        <div class="input-group">
                            <input type="date" name="tglakhir" id="tglakhir" class="form-control" required>
                        </div>
                        <a href="" onclick="return laporanPemesanan()" target="_blank" class="btn btn-primary" id="cetak"><i class="fa fa-print" aria-hidden="true"></i> Cetak Laporan Pemesanan</a>
                    </div>
                    <p class="text-konfirmasi-pesanan">
                        Sebelum konfirmasi pemesanan pastikan pelanggan sudah membayar dengan cara memeriksa bukti pembayaran dan rekening jika diperlukan
                    </p>
                </div>     
                <?php if(!empty($data)): ?>
                    <div class="box-body">
                        <div class="table-responsive">
                                <table class="table myTable">
                                    <thead class="text-primary">
                                        <th>No</th>
                                        <th>ID Pesanan</th>
                                        <th>Atas Nama</th>
                                        <th>Tanggal Pesan</th>
                                        <th>Jam</th>
                                        <th>Total</th>
                                        <th>Layanan</th>
                                        <th>Konfirmasi Status</th>
                                        <th>Aksi</th>                                                                              
                                    </thead>
                                    <tbody>
                                    <?php
                                        $no = 1
                                    ?>                                
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>                                                                                                                                                                                                                                                          
                                            <td><?php echo e($no++); ?></td>                                            
                                            <td>ME201400<?php echo e($dt->id); ?></td>
                                            <td><?php echo e($dt->user->name); ?></td>
                                            <td><?php echo e($dt->tanggal); ?></td>
                                            <td><?php echo e($dt->jam); ?></td>
                                            <td>Rp. <?php echo e(number_format($dt->total)); ?></td>
                                            <td><?php echo e($dt->layanan->jenis); ?></td>
                                            <td>                                            
                                                <div class="form-check">
                                                    <form action="/admin/konfirmasipemesanan" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        
                                                        <input type="hidden" name="id" value="<?php echo $dt->pembayaran[0]->id ?>">                                
                                                        <input type="checkbox" class="form-check-input" name="status_bayar" value="<?php echo e($dt->pembayaran[0]->status_bayar == "1" ? "0" :"1"); ?>" <?php echo e($dt->pembayaran[0]->status_bayar == "1" ? 'checked' : null); ?> onclick="event.preventDefault();this.form.submit()">                                                                                                  
                                                        <?php if($dt->pembayaran[0]->status_bayar == "1"): ?>
                                                            Sudah Dibayar
                                                        <?php else: ?>
                                                            Belum Dibayar
                                                        <?php endif; ?>
                                                    </form> 
                                                </div>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/admin/pemesanan')); ?>/<?php echo e($dt->id); ?>" class="btn btn-primary">Detail</a>                                                                                                                                                                                                
                                            </td>                                       
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>                                
                                </table>
                            </div>
                        </div>
                    
                <?php else: ?>
                    <div class="box-body">
                        Data tidak ditemukan
                    </div>
                <?php endif; ?>        
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="modal-detail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel">Detail Pesanan</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <table class="table table-bordered no-margin">
                <tbody>
                    <tr>
                        <th>Atas Nama</th>
                        <td><span id="name"></span></td>
                    </tr>
                    <tr>
                        <th>Menu</th>
                        <td><span id="menu"></span></td>
                    </tr>
                    <tr>
                        <th>Menu</th>
                        <td><span id="menu"></span></td>
                    </tr>
                    <tr>
                        <th>Total Bayar</th>
                        <td><span id="total"></span></td>
                    </tr>
                    <tr>
                        <th>Bukti Pembayaran</th>
                        <td><img id="bukti_foto" width="50%"></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Send message</button>
        </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })

    $(document).ready(function() {
        $(document).on('click', '#detail', function() {
            var name = $(this).data('name');
            var menu = $(this).data('menu');
            var total = $(this).data('total');
            var buktifoto = $(this).data('buktifoto');
            $('#name').text(name);
            $('#menu').text(menu);
            $('#total').text(total);
            $('#bukti_foto').attr("src",$(this).data('buktifoto'));
        })
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/pesan.blade.php ENDPATH**/ ?>