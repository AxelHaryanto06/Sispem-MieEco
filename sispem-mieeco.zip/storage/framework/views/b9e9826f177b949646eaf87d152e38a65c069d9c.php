<?php $__env->startSection('title', 'Pesan Menu'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('user/menu')); ?>">Menu</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($menu->nama_menu); ?></li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-12">
                <div class="card product-card">
                    <!-- <div class="card-header">
                        <h2 class="judulmenu"><?php echo e($menu->nama_menu); ?></h2>
                    </div> -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo e(url('img')); ?>/<?php echo e($menu->gambar); ?>" width="100%" class="rounded d-block" alt="">
                            </div>
                            <div class="col-md-6 mt-5">
                                <h2 class="judulmenu"><?php echo e($menu->nama_menu); ?></h2>
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td>Harga</td>
                                            <td>:</td>
                                            <td>Rp. <?php echo e(number_format($menu->harga)); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Deskripsi</td>
                                            <td>:</td>
                                            <td><?php echo e($menu->deskripsi); ?></td>
                                        </tr>
                                        <form action="<?php echo e(url('user/menu/pesan')); ?>/<?php echo e($menu->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>    
                                            <tr>
                                                <td>Jumlah Pesan</td>
                                                <td>:</td>
                                                <td>                                                    
                                                    <input type="number" name="jumlah_pesan" class="form-control" min="1" required="" id="">                                                    
                                                </td>
                                            </tr>                                            
                                            <tr>
                                                <td>Catatan</td>
                                                <td>:</td>
                                                <td>                                                    
                                                    <textarea class="form-control" name="catatan" rows="3"></textarea>
                                                    <button type="submit" class="btn btn-primary btn-custom mt-3"><i class="fas fa-shopping-cart"></i> Masukan Pesanan</button>
                                                </td>
                                            </tr>                                                
                                        </form>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/pesan/index.blade.php ENDPATH**/ ?>