<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <h4>Daftar Layanan</h4>
            <div class="box box-warning">
                <div class="box-header">
                    <p>
                        <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>
                        <a href="/admin/layanan/tambah" class="btn btn-sm btn-flat btn-primary"><i class="fa fa-plus"></i> Tambah Layanan</a>
                    </p>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                            <table class="table myTable">
                                <thead class="text-primary">
                                    <th>#</th>
                                    <th>Nama Layanan</th>
                                    <th>Gambar / Icon</th>                                                             
                                    <th>Aksi</th>                                                            
                                </thead>
                                <tbody>
                                    <!-- <?php echo e($no = 1); ?> -->
                                    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <tr>
                                        <td> <?php echo e($no++); ?> </td>
                                        <td> <?php echo e($layanan->jenis); ?> </td>
                                        <td> <img src="<?php echo e(url('img')); ?>/<?php echo e($layanan->icon); ?>" width="100px" height="auto" alt="image"> </td>                                        
                                        <td>
                                            <a href="<?php echo e(url('/admin/layanan/edit')); ?>/<?php echo e($layanan->id); ?>" class="btn btn-success">Edit</a>
                                            <a href="<?php echo e(url('/admin/layanan/hapus')); ?>/<?php echo e($layanan->id); ?>" class="btn btn-danger">Delete</a>
                                        </td>                                    
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/admin/layanan.blade.php ENDPATH**/ ?>