<?php $__env->startSection('title', 'Mie Eco'); ?>
<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="page-wrapper">
            <div class="row my-3">
                <div class="col-md-12 mx-auto">
                    <h3 align="center" class="header-body-mieeco my-3">
                        <b>Layanan</b>
                    </h3>
                    <div class="row">
                        <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md my-4">
                                <div class="card card-rounded">
                                    <div class="card-body d-flex flex-column text-center">
                                        <center>
                                            <img src="<?php echo e(url('img')); ?>/<?php echo e($layanan->icon); ?>" class="service-icon mb-3" alt="">
                                        </center>
                                        <h5 class="card-title mt-auto card-title-layanan"><?php echo e($layanan->jenis); ?></h5>
                                        <div class="text-center">
                                            <a href="<?php echo e(url('pesan')); ?>/<?php echo e($layanan->id); ?>" class="btn btn-primary btn-pilih mt-auto">Pilih</a>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/pesan/layanan.blade.php ENDPATH**/ ?>