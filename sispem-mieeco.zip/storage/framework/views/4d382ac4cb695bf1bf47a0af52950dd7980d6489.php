<?php $__env->startSection('title', 'Menu'); ?>
<?php $__env->startSection('content'); ?>
    <section class="judul1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="daftar-menu text-center">Daftar Menu</h1>
                </div>                
            </div>                  
        </div>
    </section>
    <section class="daftar-menu">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="card m-card">
                            <figure class="gambar-menu">
                                <img src="<?php echo e(url('img')); ?>/<?php echo e($m->gambar); ?>" class="card-img-top card-gambar" alt="...">
                            </figure>                        
                        <div class="card-body">
                            <h5 class="card-title nama-menu"><?php echo e($m->nama_menu); ?></h5>
                            <p class="card-text">
                                <strong class="harga">Harga :</strong> Rp. <?php echo e(number_format($m->harga)); ?> <br>
                            </p>
                            <a href="<?php echo e(url('user/menu/pesan')); ?>/<?php echo e($m->id); ?>" class="btn btn-primary btn-pesan">Pesan</a>
                            
                        </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>            
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Axel\xampp\htdocs\sispem-mieeco\resources\views/pesanmenu.blade.php ENDPATH**/ ?>